#include<Stdio.h>
void main()
{
    int a,b,c,avg;
    printf("Enter three number :");
    scanf("%d%d%d",&a,&b,&c);
    avg=(a+b+c)/3;
    printf("Average of three number :%d",avg);
}