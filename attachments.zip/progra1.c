int main()
{
    int x=-2;
  if(!0==1)
  printf("Yes\n");
  else
  printf("No\n");

    return 0;
}