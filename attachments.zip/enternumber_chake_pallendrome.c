#include<stdio.h>
int main()
{
    int n,i;
    for(i=0;i<+n;i++)
    {
        if(n!=n-1-i)
        {
         printf("Not Palindrome");
            break;
        }
        if(i==n/2)
        {
            printf("Palindrome");
        }
    }
    return 0;
}