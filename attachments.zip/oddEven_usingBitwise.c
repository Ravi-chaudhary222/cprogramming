// Find odd or even using bitwise operator
//4. find exact power of two of a given number using bitwise operator
//1. 
#include<stdio.h>
int main()
{
    int n;
    printf("Enter number :");
    scanf("%d",&n);

    do
    {
        
    } while ({/* condition */});
    

}