printf("Not Palindrome");
            break;